package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.myapplication.adapter.GoalAdapter;
import com.example.myapplication.dao.GoalDAO;
import com.example.myapplication.dao.GoalDAOSQLImpl;
import com.example.myapplication.dao.TaskDAO;
import com.example.myapplication.dao.TaskDAOSQLImpl;
import com.example.myapplication.model.Goal;
import com.example.myapplication.model.Task;
import com.example.myapplication.model.User;

import java.util.ArrayList;

public class HomepageActivity extends AppCompatActivity {

    private GoalDAO goalDAO;
    private TaskDAO taskDAO;

    private Button btn_add;
    private Button btn_history;
    private String user;

    private RecyclerView rv_list;
    private ArrayList<Goal> goalArrayList;
    private ArrayList<Goal> inProgressGoals;
    private GoalAdapter goalAdapter;

    private ArrayList<Task> taskArrayList;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.homepage);

        goalDAO = new GoalDAOSQLImpl(getApplicationContext());
        taskDAO = new TaskDAOSQLImpl(getApplicationContext());

        init();

        Bundle b = getIntent().getExtras();

        if (b != null) {
            user = b.getString("user");
        }


        setLists();

        rv_list.setLayoutManager(new LinearLayoutManager(getApplicationContext()));

        goalAdapter = new GoalAdapter(getApplicationContext(),inProgressGoals);

        rv_list.setAdapter(goalAdapter);

        btn_history.setOnClickListener(view->{
            Bundle bundle = new Bundle();

            bundle.putString("user",user);
            Intent intent = new Intent(getApplicationContext(),AddActivity.class);
            intent.putExtras(bundle);
            view.getContext().startActivity(intent);
        });
        btn_add.setOnClickListener(view-> {
            setLists();
            Bundle bundle = new Bundle();

            bundle.putString("user",user);
            bundle.putInt("id",goalArrayList.size());

            Intent intent = new Intent(getApplicationContext(),AddActivity.class);
            intent.putExtras(bundle);
            view.getContext().startActivity(intent);
        });
    }

    public void setLists() {

        ArrayList<Goal> tempList;
        tempList = goalDAO.getGoal();
        goalArrayList = new ArrayList<>();
        inProgressGoals = new ArrayList<>();

        for (int i = 0;i < tempList.size();i++) {
            if (tempList.get(i).getUser().compareTo(user) == 0) {
                goalArrayList.add(tempList.get(i));
            }
        }
        if (goalArrayList.size() > 0) {
            ArrayList<Task> tempTasks = taskDAO.getTask();
            for (int i = 0;i< goalArrayList.size();i++) {
                for (int j = 0;j < tempTasks.size();j++) {
                    if (tempTasks.get(j).getMid().compareTo(goalArrayList.get(i).getId()) == 0) {
                        goalArrayList.get(i).addTask(tempTasks.get(j));
                    }
                }
            }
        }

        for (int i = 0;i<goalArrayList.size();i++) {
            if (!goalArrayList.get(i).getStatus()) {
                inProgressGoals.add(goalArrayList.get(i));
            }
        }
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        Log.d("beep", "onRestart: invoked");
        setLists();
        rv_list.setLayoutManager(new LinearLayoutManager(getApplicationContext()));

        goalAdapter = new GoalAdapter(getApplicationContext(),inProgressGoals);

        rv_list.setAdapter(goalAdapter);
    }

    public void init() {
        btn_add = (Button) findViewById(R.id.btn_new);
        btn_history = (Button) findViewById((R.id.btn_history));
        rv_list = (RecyclerView) findViewById(R.id.recyclerView);
    }
}

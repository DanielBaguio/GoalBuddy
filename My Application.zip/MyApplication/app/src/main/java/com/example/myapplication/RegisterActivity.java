package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.os.PersistableBundle;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

import com.example.myapplication.dao.UserDAO;
import com.example.myapplication.dao.UserDAOSQLImpl;
import com.example.myapplication.model.User;

import java.util.ArrayList;

public class RegisterActivity extends AppCompatActivity {

    private UserDAO userDAO;

    private EditText et_fname;
    private EditText et_lname;
    private EditText et_dname;
    private EditText et_pass;
    private EditText et_confirmpass;

    private Button btn_cancel;
    private Button btn_register;

    private ArrayList<User> existing;
    private boolean unique;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.register);

        userDAO = new UserDAOSQLImpl(getApplicationContext());
        init();

        existing = userDAO.getUser();

        btn_register.setOnClickListener(view->{
            String user = et_dname.getText().toString();
            String pass1 = et_pass.getText().toString();
            String pass2 = et_confirmpass.getText().toString();
            unique = true;
            if (existing != null && user.compareTo("") != 0) {
                for (int i = 0; i < existing.size();i++){
                    if (user.compareTo(existing.get(i).getDname()) == 0)
                        unique = false;
                }
            }
            if (unique) {
                if (pass1.compareTo(pass2) == 0 && pass1.compareTo("") != 0) {
                    String fname = et_fname.getText().toString();
                    String lname = et_lname.getText().toString();
                    if (fname.compareTo("") != 0 && lname.compareTo("") != 0) {
                        User temp = new User(fname,lname,user,pass1);
                        userDAO.addUser(temp);
                        Bundle b = new Bundle();
                        b.putString("user",user);
                        Intent i = new Intent(getApplicationContext(),HomepageActivity.class);
                        i.putExtras(b);
                        startActivity(i);
                        finish();
                    }
                }
            }
        });

        btn_cancel.setOnClickListener(view->{
            finish();
        });
    }

    private void init() {
        et_fname = (EditText) findViewById(R.id.register_fname);
        et_lname = (EditText) findViewById(R.id.register_lname);
        et_dname = (EditText) findViewById(R.id.register_username);
        et_pass = (EditText) findViewById(R.id.register_password);
        et_confirmpass = (EditText) findViewById(R.id.register_cpassword);

        btn_register = (Button) findViewById(R.id.btn_register);
        btn_cancel = (Button) findViewById(R.id.btn_back);
        existing = new ArrayList<>();
    }
}

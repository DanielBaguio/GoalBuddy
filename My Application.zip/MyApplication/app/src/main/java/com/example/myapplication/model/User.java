package com.example.myapplication.model;

public class User {
    private String fname = "";
    private String lname = "";
    private String dname = "";
    private String pass = "";

    public User(String fname, String lname, String dname, String pass) {
        this.fname = fname;
        this.dname = dname;
        this.lname = lname;
        this.pass = pass;
    }

    public String getFname() {
        return fname;
    }

    public void setFname(String fname) {
        this.fname = fname;
    }

    public String getLname() {
        return lname;
    }

    public void setLname(String lname) {
        this.lname = lname;
    }

    public String getDname() {
        return dname;
    }

    public void setDname(String dname) {
        this.dname = dname;
    }

    public String getPass() {
        return pass;
    }

    public void setPass(String pass) {
        this.pass = pass;
    }
}

package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

import com.example.myapplication.dao.UserDAO;
import com.example.myapplication.dao.UserDAOSQLImpl;
import com.example.myapplication.model.User;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private UserDAO userDAO;

    private EditText et_user;
    private EditText et_password;
    private Button btn_login;
    private Button btn_register;

    private ArrayList<User> existing;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login);

        userDAO = new UserDAOSQLImpl(getApplicationContext());

        init();

        existing = userDAO.getUser();

        btn_login.setOnClickListener(view->{
            String user = et_user.getText().toString();
            String password = et_password.getText().toString();

            if (user.compareTo("") != 0 && password.compareTo("") != 0){
                int index = -1;
                for (int i = 0;i<existing.size();i++) {
                    if (existing.get(i).getDname().compareTo(user) == 0) {
                        if (existing.get(i).getPass().compareTo(password) == 0) {
                            index = i;
                        }
                    }
                }
                if (index != -1) {
                    Bundle b = new Bundle();

                    b.putString("user",user);
                    Intent i = new Intent(getApplicationContext(),HomepageActivity.class);
                    i.putExtras(b);
                    startActivity(i);
                }
            }
        });

        btn_register.setOnClickListener(view->{
            Intent i = new Intent(getApplicationContext(),RegisterActivity.class);
            startActivity(i);
        });
    }

    private void init() {
        et_user = (EditText) findViewById(R.id.login_username);
        et_password = (EditText) findViewById(R.id.login_password);
        btn_login = (Button) findViewById(R.id.btn_login);
        btn_register = (Button) findViewById(R.id.btn_register);
        existing = new ArrayList<>();
    }

    @Override
    protected void onResume() {
        super.onResume();
        existing = userDAO.getUser();
    }
}
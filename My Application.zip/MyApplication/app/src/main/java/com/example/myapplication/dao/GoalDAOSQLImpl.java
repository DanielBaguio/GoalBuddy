package com.example.myapplication.dao;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.example.myapplication.model.Goal;

import java.util.ArrayList;

public class GoalDAOSQLImpl implements GoalDAO{
    private SQLiteDatabase database;
    private GoalDatabase goalDatabase;

    public GoalDAOSQLImpl(Context context) {
        goalDatabase = new GoalDatabase(context);
    }

    @Override
    public void addGoal(Goal newGoal) {
        database = goalDatabase.getWritableDatabase();


        ContentValues values = new ContentValues();

        values.put(GoalDatabase.GOAL_MILESTONE,newGoal.getId());
        values.put(GoalDatabase.GOAL_NAME,newGoal.getName());
        values.put(GoalDatabase.GOAL_USER,newGoal.getUser());

        long entry = database.insert(GoalDatabase.TABLE_GOAL,null,values);
        database.close();
    }

    @Override
    public ArrayList<Goal> getGoal() {
        ArrayList<Goal> result = new ArrayList<>();
        database = goalDatabase.getReadableDatabase();

        String[] columns = {
                goalDatabase.GOAL_MILESTONE,
                goalDatabase.GOAL_NAME,
                goalDatabase.GOAL_USER,
        };

        Cursor cursor = database.query(
                goalDatabase.TABLE_GOAL,
                columns,
                null,
                null,
                null,
                null,
                null
        );

        cursor.moveToFirst();

        while(!cursor.isAfterLast()) {
            Goal temp = new Goal(
                    cursor.getString(0),
                    cursor.getString(1),
                    cursor.getString(2));
            result.add(temp);
            cursor.moveToNext();
        }

        cursor.close();
        database.close();
        return result;
    }
}

package com.example.myapplication.adapter;

import android.content.ContentValues;
import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.example.myapplication.R;
import com.example.myapplication.dao.TaskDAO;
import com.example.myapplication.dao.TaskDAOSQLImpl;
import com.example.myapplication.model.Task;

import java.util.ArrayList;

public class TaskAdapter extends RecyclerView.Adapter<TaskAdapter.TaskViewHolder> {

    private ArrayList<Task> taskArrayList;
    private Context context;

    private TaskDAO taskDAO;

    public TaskAdapter(Context context, ArrayList<Task> taskArrayList) {
        this.taskArrayList = taskArrayList;
        this.context = context;
    }

    @Override
    public TaskViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from((parent.getContext()))
                .inflate(R.layout.item_task_view,parent,false);

        TaskViewHolder taskViewHolder = new TaskViewHolder(view);

        return taskViewHolder;
    }

    @Override
    public void onBindViewHolder(TaskViewHolder holder, int position) {


        holder.tv_desc.setText(taskArrayList.get(position).getDesc());

        if (taskArrayList.get(position).getDone()) {
            holder.tv_status.setText("Done");
            holder.btn_fin.setVisibility(View.GONE);
        }
        else {
            holder.tv_status.setText("In Progress");
            holder.btn_fin.setOnClickListener(view->{
                taskDAO = new TaskDAOSQLImpl(view.getContext());

                taskArrayList.get(position).setDone(true);;
                holder.tv_status.setText("Done");
                // update database
                boolean updated = taskDAO.updateData(taskArrayList.get(position));
                if (updated) {
                    Log.d("beep", "onBindViewHolder: updated");
                }
                else {
                    Log.d("beep","not updated");
                }
                //
                ViewGroup parentView = (ViewGroup) view.getParent();
                parentView.removeView(view);
            });
        }

    }

    @Override
    public int getItemCount() {
        return taskArrayList.size();
    }

    protected class TaskViewHolder extends RecyclerView.ViewHolder{
        TextView tv_desc;
        TextView tv_status;
        Button btn_fin;

        public TaskViewHolder(View view){
            super(view);
            tv_desc = (TextView) view.findViewById(R.id.tv_desc);
            tv_status = (TextView) view.findViewById(R.id.status);
            btn_fin = (Button) view.findViewById(R.id.btn_finish);
        }
    }
}

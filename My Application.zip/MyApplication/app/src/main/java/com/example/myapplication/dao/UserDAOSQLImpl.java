package com.example.myapplication.dao;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.example.myapplication.model.User;

import java.util.ArrayList;

public class UserDAOSQLImpl implements UserDAO{
    private SQLiteDatabase database;
    private UserDatabase userDatabase;

    public UserDAOSQLImpl(Context context) {
            userDatabase = new UserDatabase(context);
    }

    @Override
    public void addUser(User newUser) {
        database = userDatabase.getWritableDatabase();


        ContentValues values = new ContentValues();

        values.put(UserDatabase.USER_FNAME,newUser.getFname());
        values.put(UserDatabase.USER_LNAME,newUser.getLname());
        values.put(UserDatabase.USER_DNAME,newUser.getDname());
        values.put(UserDatabase.USER_PASS,newUser.getPass());

        long entry = database.insert(UserDatabase.TABLE_USER,null,values);
        database.close();
    }

    @Override
    public ArrayList<User> getUser() {
        ArrayList<User> result = new ArrayList<>();
        database = userDatabase.getReadableDatabase();

        String[] columns = {
                UserDatabase.USER_FNAME,
                UserDatabase.USER_LNAME,
                UserDatabase.USER_DNAME,
                UserDatabase.USER_PASS,
        };

        Cursor cursor = database.query(
                UserDatabase.TABLE_USER,
                columns,
                null,
                null,
                null,
                null,
                null
        );

        cursor.moveToFirst();

        while(!cursor.isAfterLast()) {
            User temp = new User(
                    cursor.getString(0),
                    cursor.getString(1),
                    cursor.getString(2),
                    cursor.getString(3));
            result.add(temp);
            cursor.moveToNext();
        }

        cursor.close();
        database.close();
        return result;
    }
}

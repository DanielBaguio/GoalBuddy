package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.os.PersistableBundle;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.myapplication.adapter.AddAdapter;
import com.example.myapplication.dao.GoalDAO;
import com.example.myapplication.dao.GoalDAOSQLImpl;
import com.example.myapplication.dao.TaskDAO;
import com.example.myapplication.dao.TaskDAOSQLImpl;
import com.example.myapplication.model.Goal;
import com.example.myapplication.model.Task;

import java.util.ArrayList;

public class AddActivity extends AppCompatActivity {

    private GoalDAO goalDAO;
    private TaskDAO taskDAO;

    private EditText et_name;
    private EditText et_task;

    private Button btn_add;
    private Button btn_back;
    private Button submit;

    private RecyclerView rv_list;
    private ArrayList<Task> taskArrayList;
    private AddAdapter addAdapter;

    private String user;
    private String id;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.goal_input);

        taskDAO = new TaskDAOSQLImpl(getApplicationContext());
        goalDAO = new GoalDAOSQLImpl(getApplicationContext());

        init();

        Bundle b = getIntent().getExtras();
        user = b.getString("user");
        id = user+b.getInt("id");


        rv_list.setLayoutManager(new GridLayoutManager(getApplicationContext(),2));
        addAdapter = new AddAdapter(getApplicationContext(),taskArrayList);

        rv_list.setAdapter(addAdapter);
        submit.setOnClickListener(view->{
            if (taskArrayList.size()>0 && et_name.getText().toString().compareTo("") != 0) {
                for (int i = 0;i<taskArrayList.size();i++) {
                    taskDAO.addTask(taskArrayList.get(i));
                    Log.d("beep", "onCreate: " + taskArrayList.get(i).getTid());
                }
                Goal tempGoal = new Goal(id,et_name.getText().toString(),user);
                goalDAO.addGoal(tempGoal);

                finish();
            }
        });
        btn_add.setOnClickListener(view->{
            if (et_task.getText().toString().compareTo("") != 0) {
                taskArrayList.add(0,new Task(id+"_"+taskArrayList.size(),
                        et_task.getText().toString(),
                        id,
                        false));
                addAdapter.notifyItemInserted(0);
                addAdapter.notifyDataSetChanged();
            }
        });
        btn_back.setOnClickListener(view->{
            finish();
        });
    }

    public void init() {
        btn_add = (Button) findViewById(R.id.btn_task);
        submit = (Button) findViewById(R.id.btn_goal);
        btn_back = (Button) findViewById(R.id.goal_back);
        et_name = (EditText) findViewById(R.id.goal_name);
        et_task = (EditText) findViewById(R.id.task_name);
        rv_list = (RecyclerView) findViewById(R.id.rv_add_task);

        taskArrayList = new ArrayList<>();
    }
}

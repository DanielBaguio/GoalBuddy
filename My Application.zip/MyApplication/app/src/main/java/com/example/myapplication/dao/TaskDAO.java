package com.example.myapplication.dao;

import com.example.myapplication.model.Task;

import java.util.ArrayList;

public interface TaskDAO {
    void addTask(Task newTask);
    ArrayList<Task> getTask();
    Boolean updateData(Task updateTask);
}

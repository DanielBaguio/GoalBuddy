package com.example.myapplication.dao;

import com.example.myapplication.model.Goal;

import java.util.ArrayList;

public interface GoalDAO {
    void addGoal(Goal newGoal);
    ArrayList<Goal> getGoal();
}

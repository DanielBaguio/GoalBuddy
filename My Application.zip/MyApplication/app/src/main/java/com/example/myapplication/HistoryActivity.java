package com.example.myapplication;

import android.os.Bundle;
import android.os.PersistableBundle;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.myapplication.adapter.GoalAdapter;
import com.example.myapplication.dao.GoalDAO;
import com.example.myapplication.dao.TaskDAO;
import com.example.myapplication.model.Goal;
import com.example.myapplication.model.Task;

import java.util.ArrayList;

public class HistoryActivity extends AppCompatActivity {

    private GoalDAO goalDAO;
    private TaskDAO taskDAO;

    private String user;
    private RecyclerView rv_list;
    private ArrayList<Goal> goalArrayList;
    private ArrayList<Goal> doneGoals;
    private GoalAdapter goalAdapter;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.history);

        init();

        Bundle b = getIntent().getExtras();

        if (b != null) {
            user = b.getString("user");
        }

        ArrayList<Goal> tempList;
        tempList = goalDAO.getGoal();
        goalArrayList = new ArrayList<>();
        doneGoals = new ArrayList<>();

        for (int i = 0;i < tempList.size();i++) {
            if (tempList.get(i).getUser().compareTo(user) == 0) {
                goalArrayList.add(tempList.get(i));
            }
        }
        if (goalArrayList.size() > 0) {
            ArrayList<Task> tempTasks = taskDAO.getTask();
            for (int i = 0;i< goalArrayList.size();i++) {
                for (int j = 0;j < tempTasks.size();j++) {
                    if (tempTasks.get(j).getMid().compareTo(goalArrayList.get(i).getId()) == 0) {
                        goalArrayList.get(i).addTask(tempTasks.get(j));
                    }
                }
            }
        }

        for (int i = 0;i<goalArrayList.size();i++) {
            if (goalArrayList.get(i).getStatus()) {
                doneGoals.add(goalArrayList.get(i));
            }
        }


        rv_list.setLayoutManager(new LinearLayoutManager(getApplicationContext()));

        goalAdapter = new GoalAdapter(getApplicationContext(),doneGoals);

        rv_list.setAdapter(goalAdapter);

    }

    public void init(){
        rv_list = (RecyclerView) findViewById(R.id.history_list);


    }
}

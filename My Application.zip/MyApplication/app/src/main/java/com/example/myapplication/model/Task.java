package com.example.myapplication.model;

public class Task {
    private String tid;
    private String desc;
    private String mid;
    private Boolean done;

    public Task(String tid, String desc,String mid, Boolean done) {
        this.tid = tid;
        this.desc = desc;
        this.done = done;
        this.mid = mid;
    }

    public String getTid() {
        return tid;
    }

    public void setTid(String tid) {
        this.tid = tid;
    }

    public String getMid() {
        return mid;
    }

    public void setMid(String mid) {
        this.mid = mid;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public Boolean getDone() {
        return done;
    }

    public void setDone(Boolean done) {
        this.done = done;
    }
}

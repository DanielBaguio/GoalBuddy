package com.example.myapplication.dao;

import com.example.myapplication.model.User;

import java.util.ArrayList;

public interface UserDAO {
    void addUser(User newUser);
    ArrayList<User> getUser();
}

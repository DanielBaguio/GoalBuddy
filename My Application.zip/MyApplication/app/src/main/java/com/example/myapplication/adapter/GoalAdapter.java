package com.example.myapplication.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.myapplication.R;
import com.example.myapplication.model.Goal;

import java.util.ArrayList;

public class GoalAdapter extends RecyclerView.Adapter<GoalAdapter.GoalViewHolder> {

    private ArrayList<Goal> goalArrayList;
    private Context context;

    private TaskAdapter taskAdapter;

    public GoalAdapter(Context context, ArrayList<Goal> goalArrayList) {
        this.goalArrayList = goalArrayList;
        this.context = context;
    }

    @Override
    public GoalViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_goal_view,parent,false);

        GoalViewHolder goalViewHolder = new GoalViewHolder(view);
        return goalViewHolder;
    }

    @Override
    public void onBindViewHolder(GoalViewHolder holder, int position) {

        holder.tv_title.setText(goalArrayList.get(position).getName());
        //holder.tv_title.setText(goalArrayList.get(position).getGoals().size()+" ");

        holder.rv_list.setLayoutManager(new GridLayoutManager(context.getApplicationContext(),2));

        taskAdapter = new TaskAdapter(context.getApplicationContext(), goalArrayList.get(position).getGoals());

        holder.rv_list.setAdapter(taskAdapter);
    }

    @Override
    public int getItemCount() {
        return goalArrayList.size();
    }

    protected class GoalViewHolder extends RecyclerView.ViewHolder {
        TextView tv_title;
        RecyclerView rv_list;

        public GoalViewHolder(View view) {
            super(view);
            tv_title = (TextView) view.findViewById(R.id.milestone_title);
            rv_list = (RecyclerView) view.findViewById(R.id.milestone_list);
        }
    }
}

package com.example.myapplication.dao;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class TaskDatabase extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "task.db";
    private static final int DATABASE_VERSION = 3;

    public static final String TABLE_TASK = "table_task";
    public static final String TASK_ID = "id";
    public static final String TASK_TID = "tid";
    public static final String TASK_DESC = "descript";
    public static final String TASK_MILESTONE = "mid";
    public static final String TASK_DONE = "done";

    public static final String CREATE_TASK_TABLE =
            "create table " + TABLE_TASK +
                    "("
                    + TASK_ID + " integer primary key autoincrement, "
                    + TASK_TID + " text, "
                    + TASK_DESC + " text, "
                    + TASK_MILESTONE + " text, "
                    + TASK_DONE + " text ); ";

    public TaskDatabase(Context context) {
        super(context,DATABASE_NAME,null,DATABASE_VERSION);
    }


    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_TASK_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_TASK);
        onCreate(db);
    }
}

package com.example.myapplication.dao;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import com.example.myapplication.model.Task;
import com.example.myapplication.model.User;

import java.util.ArrayList;

public class TaskDAOSQLImpl implements TaskDAO{
    private SQLiteDatabase database;
    private TaskDatabase taskDatabase;

    public TaskDAOSQLImpl(Context context) {
        taskDatabase = new TaskDatabase(context);
    }

    @Override
    public void addTask(Task newTask) {
        database = taskDatabase.getWritableDatabase();


        ContentValues values = new ContentValues();

        values.put(TaskDatabase.TASK_TID,newTask.getTid());
        values.put(TaskDatabase.TASK_DESC,newTask.getDesc());
        values.put(TaskDatabase.TASK_MILESTONE,newTask.getMid());
        values.put(TaskDatabase.TASK_DONE,newTask.getDone().toString());

        long entry = database.insert(TaskDatabase.TABLE_TASK,null,values);
        database.close();
    }

    @Override
    public ArrayList<Task> getTask() {
        ArrayList<Task> result = new ArrayList<>();
        database = taskDatabase.getReadableDatabase();

        String[] columns = {
                TaskDatabase.TASK_TID,
                TaskDatabase.TASK_DESC,
                TaskDatabase.TASK_MILESTONE,
                TaskDatabase.TASK_DONE,
        };

        Cursor cursor = database.query(
                TaskDatabase.TABLE_TASK,
                columns,
                null,
                null,
                null,
                null,
                null
        );

        cursor.moveToFirst();

        while(!cursor.isAfterLast()) {

            Task temp = new Task(
                    cursor.getString(0),
                    cursor.getString(1),
                    cursor.getString(2),
                    Boolean.parseBoolean(cursor.getString(3)));
            result.add(temp);
            cursor.moveToNext();
        }

        cursor.close();
        database.close();
        return result;
    }

    public Boolean updateData(Task updateTask) {
        database = taskDatabase.getWritableDatabase();
        ContentValues cv = new ContentValues();

        cv.put(TaskDatabase.TASK_TID,updateTask.getTid());
        cv.put(TaskDatabase.TASK_DESC,updateTask.getDesc());
        cv.put(TaskDatabase.TASK_MILESTONE,updateTask.getMid());
        cv.put(TaskDatabase.TASK_DONE,updateTask.getDone().toString());
        
        Cursor cursor = database.rawQuery("SELECT * from "+TaskDatabase.TABLE_TASK
                + " where tid =?",new String[]{updateTask.getTid()});
        if (cursor.getCount()>0) {
            long result = database.update(TaskDatabase.TABLE_TASK,cv, "tid=?",new String[] { updateTask.getTid() });

            database.close();
            if (result==-1){
                return false;
            } else
                return true;
        } else return false;
    }
}

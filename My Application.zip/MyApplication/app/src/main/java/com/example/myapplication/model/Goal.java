package com.example.myapplication.model;

import java.util.ArrayList;

public class Goal {
    private String id;
    private String name;
    private String user;

    private ArrayList<Task> taskArrayList;

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public Goal(String id, String name, String user) {
        this.id = id;
        this.name = name;
        this.user = user;
        taskArrayList = new ArrayList<>();
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void addTask(Task newTask) {
        taskArrayList.add(newTask);
    }

    public ArrayList<Task> getGoals() {return taskArrayList;}

    public Boolean getStatus() {
        Boolean status = true;
        for (int i = 0;i<taskArrayList.size();i++) {
            if (!taskArrayList.get(i).getDone())
                status = false;
        }
        return status;
    }
}

package com.example.myapplication.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.myapplication.R;
import com.example.myapplication.model.Goal;
import com.example.myapplication.model.Task;

import java.util.ArrayList;

public class AddAdapter extends RecyclerView.Adapter<AddAdapter.AddViewHolder> {

    private ArrayList<Task> taskArrayList;
    private Context context;

    public AddAdapter(Context context, ArrayList<Task> taskArrayList) {
        this.taskArrayList = taskArrayList;
        this.context = context;
    }

    @Override
    public AddViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_new_goal_view,parent,false);

        AddViewHolder addViewHolder =new AddViewHolder(view);
        return addViewHolder;
    }

    @Override
    public void onBindViewHolder(AddViewHolder holder, int position) {
        holder.tv_name.setText(taskArrayList.get(position).getDesc());
        holder.btn_remove.setOnClickListener(view->{
            taskArrayList.remove(position);
            notifyItemRemoved(position);
            notifyDataSetChanged();
        });
    }

    @Override
    public int getItemCount() {
        return taskArrayList.size();
    }

    protected class AddViewHolder extends RecyclerView.ViewHolder {
        TextView tv_name;
        Button btn_remove;

        public AddViewHolder(View view) {
            super(view);
            tv_name = (TextView) view.findViewById(R.id.new_goal_name);
            btn_remove = (Button) view.findViewById(R.id.new_goal_remove);
        }
    }
}
